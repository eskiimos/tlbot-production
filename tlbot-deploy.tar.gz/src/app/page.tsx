'use client';

import { useEffect, useState } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import Image from 'next/image';

// Типы для Telegram WebApp
interface TelegramWebApp {
  ready: () => void;
  expand: () => void;
  initDataUnsafe: {
    user?: {
      id: number;
      first_name: string;
      username?: string;
    };
  };
}

declare global {
  interface Window {
    Telegram?: {
      WebApp?: TelegramWebApp;
    };
  }
}

export default function HomePage() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const isEditMode = searchParams.get('edit') === 'true';
  
  const [isClient, setIsClient] = useState(false);
  const [tg, setTg] = useState<TelegramWebApp | null>(null);
  const [userData, setUserData] = useState<{
    id: number;
    first_name: string;
    username?: string;
  } | null>(null);
  const [showRegistration, setShowRegistration] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [existingOrganization, setExistingOrganization] = useState<any>(null);

  useEffect(() => {
    console.log('🚀 Инициализация HomePage');
    setIsClient(true);
    
    console.log('🔧 Режим редактирования:', isEditMode);
    
    if (typeof window !== 'undefined' && window.Telegram?.WebApp) {
      console.log('📱 Telegram WebApp доступен');
      const webApp = window.Telegram.WebApp;
      webApp.ready();
      
      if (webApp.initDataUnsafe?.user) {
        const user = webApp.initDataUnsafe.user;
        setUserData(user);
        console.log('👤 Telegram пользователь:', user);
        
        // Проверяем, есть ли уже регистрация
        checkExistingOrganization(user.id);
      } else {
        console.log('🧪 Режим разработки с тестовыми данными');
        // В режиме разработки используем тестовые данные
        const testUser = { id: 12345, first_name: 'Тестовый', username: 'test_user' };
        setUserData(testUser);
        console.log('👤 Тестовый пользователь:', testUser);
        checkExistingOrganization(testUser.id);
      }
    } else {
      console.log('🔧 Режим разработки без Telegram');
      // В режиме разработки без Telegram
      const testUser = { id: 12345, first_name: 'Тестовый', username: 'test_user' };
      setUserData(testUser);
      console.log('👤 Тестовый пользователь (без Telegram):', testUser);
      checkExistingOrganization(testUser.id);
    }
  }, [isEditMode]);

  // Проверка существующей организации
  const checkExistingOrganization = async (telegramId: number) => {
    console.log('🔍 Проверяем существующую организацию для telegramId:', telegramId);
    try {
      setIsLoading(true);
      const response = await fetch(`/api/organizations?telegramId=${telegramId}`);
      
      console.log('📥 Ответ API организаций:', response.status, response.statusText);
      
      if (response.ok) {
        const data = await response.json();
        console.log('📋 Данные организации:', data);
        
        if (data.organization && !isEditMode) {
          // Организация уже существует, перенаправляем в каталог
          console.log('✅ Организация найдена, перенаправляем в каталог');
          router.push('/catalog');
          return;
        } else if (data.organization && isEditMode) {
          console.log('✏️ Организация найдена, но режим редактирования - показываем форму с данными');
          // В режиме редактирования сохраняем данные организации
          setExistingOrganization(data.organization);
        } else {
          console.log('ℹ️ Организация не найдена');
        }
      } else {
        console.log('⚠️ API вернул ошибку:', response.status);
      }
      
      // Показываем форму регистрации
      console.log('📝 Показываем форму регистрации');
      setShowRegistration(true);
    } catch (error) {
      console.error('❌ Ошибка проверки организации:', error);
      setShowRegistration(true);
    } finally {
      setIsLoading(false);
    }
  };

  if (!isClient || isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-gray-900 mx-auto mb-4"></div>
          <p className="text-gray-600">Загрузка...</p>
        </div>
      </div>
    );
  }

  if (showRegistration) {
    // Показываем компонент регистрации
    return (
      <RegistrationForm 
        userData={userData} 
        existingOrganization={existingOrganization}
        onComplete={() => router.push('/catalog')} 
      />
    );
  }

  const handleStartShopping = () => {
    router.push('/catalog');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100">
      <div className="container mx-auto px-4 py-12">
        <div className="max-w-4xl mx-auto text-center">
          {/* Логотип */}
          <div className="mb-8">
            <Image
              src="/TLlogo.svg"
              alt="Total Lookas"
              width={200}
              height={80}
              className="mx-auto"
              priority
            />
          </div>

          {/* Заголовок */}
          <h1 className="text-4xl md:text-6xl font-bold text-gray-900 mb-6">
            Total Lookas
          </h1>
          
          <p className="text-xl md:text-2xl text-gray-600 mb-8">
            Креативное агентство полного цикла
          </p>

          {/* Описание */}
          <div className="bg-white rounded-2xl shadow-lg p-8 mb-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">
              🎨 Превращаем корпоративный мерч в арт-объекты!
            </h2>
            <p className="text-gray-600 mb-6">
              С 2017 года объединяем дерзкий стиль с корпоративным сервисом. 
              Можем всё — быстро, смело и качественно.
            </p>
            
            <div className="grid md:grid-cols-3 gap-6 text-left">
              <div className="flex items-start space-x-3">
                <span className="text-2xl">⚡️</span>
                <div>
                  <h3 className="font-semibold text-gray-900">20 дней</h3>
                  <p className="text-sm text-gray-600">От идеи до готового продукта</p>
                </div>
              </div>
              
              <div className="flex items-start space-x-3">
                <span className="text-2xl">🎯</span>
                <div>
                  <h3 className="font-semibold text-gray-900">Полный цикл</h3>
                  <p className="text-sm text-gray-600">Дизайн → лекала → производство → логистика</p>
                </div>
              </div>
              
              <div className="flex items-start space-x-3">
                <span className="text-2xl">👕</span>
                <div>
                  <h3 className="font-semibold text-gray-900">Широкий ассортимент</h3>
                  <p className="text-sm text-gray-600">От футболок до ювелирных аксессуаров</p>
                </div>
              </div>
            </div>
          </div>

          {/* Кнопка */}
          <button
            onClick={handleStartShopping}
            className="bg-black text-white px-8 py-4 rounded-full text-lg font-semibold hover:bg-gray-800 transition-colors duration-200 shadow-lg hover:shadow-xl transform hover:-translate-y-1"
          >
            🔥 Открыть каталог
          </button>
        </div>
      </div>
    </div>
  );
}

// Компонент формы регистрации
interface RegistrationFormProps {
  userData: {
    id: number;
    first_name: string;
    username?: string;
  } | null;
  existingOrganization?: any;
  onComplete: () => void;
}

function RegistrationForm({ userData, existingOrganization, onComplete }: RegistrationFormProps) {
  const [formData, setFormData] = useState({
    contactName: existingOrganization?.contactName || userData?.first_name || '',
    inn: existingOrganization?.inn || '',
    phone: existingOrganization?.phone || '',
    email: existingOrganization?.email || ''
  });
  
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);

  const validateForm = () => {
    const newErrors: Record<string, string> = {};

    if (!formData.contactName.trim()) {
      newErrors.contactName = 'Имя контактного лица обязательно';
    }

    if (!formData.inn.trim()) {
      newErrors.inn = 'ИНН организации обязателен';
    } else if (!/^\d{10}$|^\d{12}$/.test(formData.inn)) {
      newErrors.inn = 'ИНН должен содержать 10 или 12 цифр';
    }

    if (!formData.phone.trim()) {
      newErrors.phone = 'Номер телефона обязателен';
    }

    if (formData.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = 'Некорректный формат email';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    console.log('🚀 Начинаем отправку формы регистрации');
    console.log('📋 Данные формы:', formData);
    console.log('👤 Данные пользователя:', userData);
    
    if (!validateForm()) {
      console.log('❌ Валидация не прошла');
      return;
    }

    setIsSubmitting(true);
    
    try {
      const data = {
        contactName: formData.contactName,
        inn: formData.inn,
        phone: formData.phone,
        email: formData.email,
        user: userData
      };
      
      console.log('📤 Отправляем данные на сервер:', data);
      
      const response = await fetch('/api/organizations', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
      });
      
      console.log('📥 Ответ сервера:', response.status, response.statusText);
      
      if (!response.ok) {
        const errorData = await response.text();
        console.error('❌ Ошибка ответа сервера:', errorData);
        throw new Error(`Ошибка при сохранении данных: ${response.status}`);
      }
      
      const result = await response.json();
      console.log('✅ Успешный ответ:', result);
      console.log('🎉 Организация успешно создана');
      
      // В режиме редактирования показываем успех, иначе перенаправляем
      if (existingOrganization) {
        setShowSuccess(true);
        // Автоматически скрываем уведомление через 3 секунды
        setTimeout(() => setShowSuccess(false), 3000);
      } else {
        onComplete();
      }
      
    } catch (error) {
      console.error('❌ Ошибка при сохранении:', error);
      alert('Ошибка при сохранении данных. Попробуйте еще раз.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 flex items-center justify-center p-4">
      <div className="max-w-md w-full bg-white rounded-2xl shadow-xl p-8">
        {/* Уведомление об успехе */}
        {showSuccess && (
          <div className="mb-6 p-4 bg-green-100 border border-green-400 text-green-700 rounded-lg">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                </svg>
              </div>
              <div className="ml-3">
                <p className="text-sm font-medium">
                  Данные организации успешно обновлены!
                </p>
              </div>
            </div>
          </div>
        )}
        
        <div className="text-center mb-8">
          <Image
            src="/TLlogo.svg"
            alt="Total Lookas"
            width={120}
            height={48}
            className="mx-auto mb-4"
            priority
          />
          <h1 className="text-2xl font-bold text-gray-900 mb-2">
            {existingOrganization ? 'Редактирование организации' : 'Регистрация организации'}
          </h1>
          <p className="text-gray-600">
            {existingOrganization ? 'Измените данные организации' : 'Заполните данные для продолжения'}
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Контактное лицо *
            </label>
            <input
              type="text"
              value={formData.contactName}
              onChange={(e) => setFormData({ ...formData, contactName: e.target.value })}
              className={`w-full px-4 py-3 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent ${
                errors.contactName ? 'border-red-500' : 'border-gray-300'
              }`}
              placeholder="Ваше имя"
            />
            {errors.contactName && (
              <p className="text-red-500 text-sm mt-1">{errors.contactName}</p>
            )}
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              ИНН организации *
            </label>
            <input
              type="text"
              value={formData.inn}
              onChange={(e) => setFormData({ ...formData, inn: e.target.value })}
              className={`w-full px-4 py-3 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent ${
                errors.inn ? 'border-red-500' : 'border-gray-300'
              }`}
              placeholder="1234567890"
              maxLength={12}
            />
            {errors.inn && (
              <p className="text-red-500 text-sm mt-1">{errors.inn}</p>
            )}
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Номер телефона *
            </label>
            <input
              type="tel"
              value={formData.phone}
              onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
              className={`w-full px-4 py-3 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent ${
                errors.phone ? 'border-red-500' : 'border-gray-300'
              }`}
              placeholder="+7 900 123-45-67"
            />
            {errors.phone && (
              <p className="text-red-500 text-sm mt-1">{errors.phone}</p>
            )}
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Email
            </label>
            <input
              type="email"
              value={formData.email}
              onChange={(e) => setFormData({ ...formData, email: e.target.value })}
              className={`w-full px-4 py-3 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent ${
                errors.email ? 'border-red-500' : 'border-gray-300'
              }`}
              placeholder="your@email.com"
            />
            {errors.email && (
              <p className="text-red-500 text-sm mt-1">{errors.email}</p>
            )}
          </div>

          <button
            type="submit"
            disabled={isSubmitting}
            className="w-full bg-black text-white py-3 px-4 rounded-lg font-semibold hover:bg-gray-800 transition-colors duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {isSubmitting ? 'Сохранение...' : (existingOrganization ? 'Сохранить изменения' : 'Далее')}
          </button>
        </form>

        <p className="text-xs text-gray-500 text-center mt-4">
          * Поля отмеченные * обязательны для заполнения
        </p>
      </div>
    </div>
  );
}
