-- AlterTable
ALTER TABLE "public"."product_options" ADD COLUMN     "description" TEXT;
